
console.log("client.js loaded.");

